package com.example.aivtuber.live2d

import android.widget.ImageView
import androidx.annotation.DrawableRes
import com.example.aivtuber.R

/**
 * Live2D Cubism SDK를 아직 연동하지 않은 상태에서도 앱이 바로 동작하도록 만든
 * "입모양 2장 교체" 방식의 임시 캐릭터 컨트롤러.
 *
 * 나중에 실제 Live2D 모델을 연동할 때는 이 클래스 대신
 * docs/live2d_cubism_integration_guide.md 에 정리된 가이드를 참고해
 * GLSurfaceView 기반의 실제 Cubism 렌더러 구현체로 교체하면 됨
 * (Live2DController 인터페이스만 지키면 ChatViewModel 쪽 코드는 수정할 필요 없음).
 */
class Live2DPlaceholderController(
    private val imageView: ImageView,
    @DrawableRes private val closedMouthRes: Int = R.drawable.ic_character_mouth_closed,
    @DrawableRes private val openMouthRes: Int = R.drawable.ic_character_mouth_open,
    private val openThreshold: Float = 0.35f
) : Live2DController {

    override fun loadModel(modelDir: String, modelJsonFileName: String) {
        // 플레이스홀더 구현이므로 실제 모델 파일(.model3.json)은 사용하지 않음.
        imageView.setImageResource(closedMouthRes)
    }

    override fun setMouthOpenY(value: Float) {
        imageView.setImageResource(if (value > openThreshold) openMouthRes else closedMouthRes)
    }

    override fun startIdleMotion() {
        // 플레이스홀더에서는 별도 idle 애니메이션 없음. 필요하면 ObjectAnimator 등으로 확장 가능.
    }

    override fun onSurfaceChanged(width: Int, height: Int) {
        // ImageView 기반이라 별도 처리 불필요.
    }

    override fun release() {
        // 별도로 해제할 네이티브 리소스 없음.
    }
}
