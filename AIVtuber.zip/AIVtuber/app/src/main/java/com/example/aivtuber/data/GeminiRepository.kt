package com.example.aivtuber.data

import com.example.aivtuber.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Google Gemini API(generateContent)를 직접 REST로 호출하는 레포지토리.
 *
 * 참고: 기본 모델은 안정적인 정식 버전인 "gemini-2.5-flash"를 사용함
 * (preview/latest 별칭은 트래픽이 몰릴 때 503(과부하) 응답이 잦아서 안정 버전으로 변경).
 * 그래도 503이 뜨면 최대 2번 자동 재시도함.
 */
class GeminiRepository(
    private val apiKey: String = BuildConfig.GEMINI_API_KEY,
    private val model: String = "gemini-2.5-flash",
    /** 캐릭터의 말투/설정을 정의하는 시스템 프롬프트. 여기서 버튜버 캐릭터 성격을 커스텀하면 됨. */
    private val systemInstruction: String = "너는 밝고 친근한 버튜버 캐릭터야. 짧고 자연스러운 구어체로 대답해."
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val endpoint: String
        get() = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"

    /**
     * 사용자 발화(prompt)를 보내고 AI의 답변 텍스트를 반환.
     * 실패 시 예외를 던지므로 호출부(ViewModel)에서 try/catch로 처리할 것.
     */
    suspend fun generateReply(userText: String): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            throw IllegalStateException(
                "GEMINI_API_KEY가 비어 있습니다. local.properties에 키를 설정했는지 확인하세요."
            )
        }

        val requestJson = JSONObject().apply {
            put("system_instruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
            })
            put("contents", JSONArray().put(
                JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", userText)))
                }
            ))
        }

        val bodyText = requestJson.toString()

        // Gemini 서버가 일시적으로 과부하(HTTP 503)일 때를 대비해 짧게 대기 후 최대 2번 재시도.
        var lastError: Exception? = null
        repeat(3) { attempt ->
            val body = bodyText.toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(endpoint)
                .addHeader("x-goog-api-key", apiKey)
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build()

            try {
                client.newCall(request).execute().use { response ->
                    val responseBody = response.body?.string().orEmpty()
                    if (response.isSuccessful) {
                        return@withContext parseReply(responseBody)
                    }
                    if (response.code == 503 && attempt < 2) {
                        lastError = IllegalStateException("Gemini 서버 과부하 (503), 재시도 중…")
                        Thread.sleep(1500L * (attempt + 1))
                        return@repeat
                    }
                    throw IllegalStateException("Gemini API 오류 (HTTP ${response.code}): $responseBody")
                }
            } catch (e: java.io.IOException) {
                lastError = e
                if (attempt < 2) Thread.sleep(1500L * (attempt + 1))
            }
        }
        throw lastError ?: IllegalStateException("Gemini 응답을 받지 못했습니다.")
    }

    private fun parseReply(rawJson: String): String {
        val root = JSONObject(rawJson)
        val candidates = root.optJSONArray("candidates")
            ?: throw IllegalStateException("응답에 candidates가 없습니다: $rawJson")
        val firstCandidate = candidates.getJSONObject(0)
        val parts = firstCandidate.getJSONObject("content").getJSONArray("parts")
        val textBuilder = StringBuilder()
        for (i in 0 until parts.length()) {
            textBuilder.append(parts.getJSONObject(i).optString("text"))
        }
        return textBuilder.toString().trim()
    }
}
