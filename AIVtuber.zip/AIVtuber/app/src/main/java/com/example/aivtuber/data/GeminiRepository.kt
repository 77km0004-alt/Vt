package com.example.aivtuber.data

import com.example.aivtuber.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Google Gemini API(generateContent)를 직접 REST로 호출하는 레포지토리.
 *
 * 참고: 모델명은 하드코딩된 특정 버전 대신 Google이 제공하는 별칭(alias)인
 * "gemini-flash-latest"를 기본값으로 사용함. 필요하면 특정 버전(예: "gemini-2.5-flash")으로
 * 바꿔도 됨.
 */
class GeminiRepository(
    private val apiKey: String = BuildConfig.GEMINI_API_KEY,
    private val model: String = "gemini-flash-latest",
    /** 캐릭터의 말투/설정을 정의하는 시스템 프롬프트. 여기서 버튜버 캐릭터 성격을 커스텀하면 됨. */
    private val systemInstruction: String = "너는 밝고 친근한 버튜버 캐릭터야. 짧고 자연스러운 구어체로 대답해."
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val endpoint: String
        get() = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"

    /**
     * 사용자 발화(prompt)를 보내고 AI의 답변 텍스트를 반환.
     * 실패 시 예외를 던지므로 호출부(ViewModel)에서 try/catch로 처리할 것.
     */
    suspend fun generateReply(userText: String): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            throw IllegalStateException(
                "GEMINI_API_KEY가 비어 있습니다. local.properties에 키를 설정했는지 확인하세요."
            )
        }

        val requestJson = JSONObject().apply {
            put("system_instruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
            })
            put("contents", JSONArray().put(
                JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", userText)))
                }
            ))
        }

        val body = requestJson.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(endpoint)
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(body)
            .build()

        client.newCall(request).execute().use { response ->
            val bodyString = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IllegalStateException("Gemini API 오류 (HTTP ${response.code}): $bodyString")
            }
            parseReply(bodyString)
        }
    }

    private fun parseReply(rawJson: String): String {
        val root = JSONObject(rawJson)
        val candidates = root.optJSONArray("candidates")
            ?: throw IllegalStateException("응답에 candidates가 없습니다: $rawJson")
        val firstCandidate = candidates.getJSONObject(0)
        val parts = firstCandidate.getJSONObject("content").getJSONArray("parts")
        val textBuilder = StringBuilder()
        for (i in 0 until parts.length()) {
            textBuilder.append(parts.getJSONObject(i).optString("text"))
        }
        return textBuilder.toString().trim()
    }
}
