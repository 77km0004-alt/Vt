package com.example.aivtuber.tts

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * 안드로이드 내장 TextToSpeech를 감싼 클래스.
 *
 * 안드로이드 TTS는 실시간 음량(볼륨) 값을 직접 제공하지 않기 때문에,
 * onRangeStart 콜백(현재 발화 중인 단어 구간)을 이용해 "단어가 나올 때마다
 * 입을 살짝 열었다가 닫는" 방식의 근사 립싱크를 구현함.
 * 실제 음량 기반 립싱크가 필요하면 별도의 TTS 엔진(음성 파일 + RMS 분석) 도입이 필요함.
 */
class TTSManager(
    context: Context,
    private val onMouthOpenValueChanged: (Float) -> Unit,
    private val onSpeechStart: () -> Unit = {},
    private val onSpeechDone: () -> Unit = {}
) {
    private var tts: TextToSpeech? = null
    private var isReady = false
    private val mainHandler = Handler(Looper.getMainLooper())

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                // 필요에 따라 Locale.JAPAN, Locale.ENGLISH 등으로 교체
                tts?.language = Locale.KOREAN
                isReady = true
                attachProgressListener()
            }
        }
    }

    private fun attachProgressListener() {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                mainHandler.post { onSpeechStart() }
            }

            override fun onDone(utteranceId: String?) {
                mainHandler.post {
                    onMouthOpenValueChanged(0f)
                    onSpeechDone()
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                mainHandler.post {
                    onMouthOpenValueChanged(0f)
                    onSpeechDone()
                }
            }

            override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                // 단어 구간이 시작될 때마다 입을 열고, 짧은 지연 후 다시 닫음(근사 립싱크)
                mainHandler.post {
                    onMouthOpenValueChanged(0.8f)
                    mainHandler.postDelayed({ onMouthOpenValueChanged(0.15f) }, 120L)
                }
            }
        })
    }

    fun speak(text: String, utteranceId: String = "ai_vtuber_utterance") {
        if (!isReady || text.isBlank()) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        tts?.stop()
        onMouthOpenValueChanged(0f)
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
