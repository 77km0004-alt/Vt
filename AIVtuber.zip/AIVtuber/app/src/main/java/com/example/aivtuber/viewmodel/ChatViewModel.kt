package com.example.aivtuber.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.aivtuber.data.GeminiRepository
import com.example.aivtuber.model.ChatMessage
import kotlinx.coroutines.launch

/**
 * 채팅 흐름 전체(사용자 입력 → Gemini 호출 → 답변 표시 → TTS 발화 트리거)를 담당.
 * TTS 실행 자체와 Live2D 렌더링은 View(Activity) 쪽에서 콜백으로 연결.
 */
class ChatViewModel(
    private val repository: GeminiRepository = GeminiRepository()
) : ViewModel() {

    /** 새 메시지가 추가될 때 View에 알림 (사용자 메시지든 AI 메시지든 모두) */
    var onMessageAdded: ((ChatMessage) -> Unit)? = null

    /** AI 답변 텍스트가 확정되어 TTS로 읽어야 할 때 호출됨 */
    var onAiReplyReady: ((String) -> Unit)? = null

    /** 에러 발생 시 View에 알림 (스낵바 등으로 표시) */
    var onError: ((String) -> Unit)? = null

    fun sendUserMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return

        onMessageAdded?.invoke(ChatMessage(trimmed, isFromUser = true))

        viewModelScope.launch {
            try {
                val reply = repository.generateReply(trimmed)
                onMessageAdded?.invoke(ChatMessage(reply, isFromUser = false))
                onAiReplyReady?.invoke(reply)
            } catch (e: Exception) {
                onError?.invoke(e.message ?: "알 수 없는 오류가 발생했습니다.")
            }
        }
    }
}
