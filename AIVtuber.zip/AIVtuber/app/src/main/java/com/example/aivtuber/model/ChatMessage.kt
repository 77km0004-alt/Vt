package com.example.aivtuber.model

/**
 * 채팅 한 줄(사용자 또는 AI 캐릭터의 발화)을 나타내는 데이터 클래스.
 */
data class ChatMessage(
    val text: String,
    val isFromUser: Boolean
)
