package com.example.aivtuber.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.aivtuber.R
import com.example.aivtuber.model.ChatMessage

class ChatAdapter(private val messages: MutableList<ChatMessage> = mutableListOf()) :
    RecyclerView.Adapter<ChatAdapter.ChatViewHolder>() {

    class ChatViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val textMessage: TextView = view.findViewById(R.id.text_message)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_chat_message, parent, false)
        return ChatViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChatViewHolder, position: Int) {
        val message = messages[position]
        holder.textMessage.text = message.text

        val layoutParams = holder.textMessage.layoutParams
        if (layoutParams is android.widget.LinearLayout.LayoutParams) {
            layoutParams.gravity = if (message.isFromUser) android.view.Gravity.END else android.view.Gravity.START
            holder.textMessage.layoutParams = layoutParams
        }
        holder.textMessage.setBackgroundResource(
            if (message.isFromUser) R.drawable.bg_bubble_user else R.drawable.bg_bubble_ai
        )
    }

    override fun getItemCount(): Int = messages.size

    fun addMessage(message: ChatMessage) {
        messages.add(message)
        notifyItemInserted(messages.size - 1)
    }
}
