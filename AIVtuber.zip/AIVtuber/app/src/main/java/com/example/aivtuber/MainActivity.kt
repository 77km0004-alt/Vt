package com.example.aivtuber

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.aivtuber.databinding.ActivityMainBinding
import com.example.aivtuber.live2d.Live2DController
import com.example.aivtuber.live2d.Live2DPlaceholderController
import com.example.aivtuber.tts.TTSManager
import com.example.aivtuber.ui.ChatAdapter
import com.example.aivtuber.viewmodel.ChatViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var chatAdapter: ChatAdapter
    private lateinit var viewModel: ChatViewModel
    private lateinit var ttsManager: TTSManager
    private lateinit var live2DController: Live2DController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[ChatViewModel::class.java]

        setupChatList()
        setupCharacter()
        setupTts()
        setupViewModelCallbacks()
        setupInputBar()
    }

    private fun setupChatList() {
        chatAdapter = ChatAdapter()
        binding.recyclerChat.layoutManager = LinearLayoutManager(this)
        binding.recyclerChat.adapter = chatAdapter
    }

    private fun setupCharacter() {
        // 지금은 플레이스홀더(입모양 2장 교체) 구현체를 사용.
        // Live2D Cubism SDK 연동 후에는 이 구현체만 실제 Cubism 기반 컨트롤러로 교체하면 됨.
        live2DController = Live2DPlaceholderController(binding.characterImage)
        live2DController.startIdleMotion()
    }

    private fun setupTts() {
        ttsManager = TTSManager(
            context = this,
            onMouthOpenValueChanged = { value -> live2DController.setMouthOpenY(value) },
            onSpeechStart = { /* 필요하면 말하기 시작 모션 트리거 */ },
            onSpeechDone = { live2DController.setMouthOpenY(0f) }
        )
    }

    private fun setupViewModelCallbacks() {
        viewModel.onMessageAdded = { message ->
            chatAdapter.addMessage(message)
            binding.recyclerChat.scrollToPosition(chatAdapter.itemCount - 1)
        }
        viewModel.onAiReplyReady = { replyText ->
            ttsManager.speak(replyText)
        }
        viewModel.onError = { errorMessage ->
            Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show()
        }
    }

    private fun setupInputBar() {
        binding.btnSend.setOnClickListener {
            val text = binding.editInput.text?.toString().orEmpty()
            viewModel.sendUserMessage(text)
            binding.editInput.text?.clear()
        }
    }

    override fun onDestroy() {
        ttsManager.shutdown()
        live2DController.release()
        super.onDestroy()
    }
}
