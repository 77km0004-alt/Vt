package com.example.aivtuber.live2d

/**
 * Live2D Cubism 모델을 제어하기 위한 추상 인터페이스.
 *
 * ChatViewModel/TTSManager는 이 인터페이스만 알면 되고, 실제 Cubism SDK와
 * 맞닿는 구현(Live2DGLRenderer 등)은 이 인터페이스 뒤에 숨김.
 * 이렇게 분리해두면, Live2D SDK를 아직 추가하지 않은 상태에서도
 * 채팅+API+TTS 파이프라인은 그대로 빌드/테스트할 수 있음
 * (NoOp 구현체를 기본으로 사용하고, SDK 연동 후 실제 구현체로 교체).
 */
interface Live2DController {

    /**
     * 모델 파일(.model3.json)을 로드.
     * @param modelDir assets 내부의 모델 폴더 경로 (예: "live2d/Hiyori")
     * @param modelJsonFileName 예: "Hiyori.model3.json"
     */
    fun loadModel(modelDir: String, modelJsonFileName: String)

    /** 입 벌림 정도를 0f(다뭄) ~ 1f(활짝 벌림) 사이 값으로 설정. TTS 콜백에서 매 프레임 호출됨. */
    fun setMouthOpenY(value: Float)

    /** 가만히 있을 때 자연스러운 흔들림 등 idle 모션 재생. */
    fun startIdleMotion()

    /** 화면 크기 변경 시 호출 (뷰포트/투영행렬 갱신용). */
    fun onSurfaceChanged(width: Int, height: Int)

    /** 액티비티 종료 시 리소스 해제. */
    fun release()
}

/**
 * Live2D SDK를 아직 연동하지 않았을 때 사용하는 임시 구현체.
 * 아무 것도 그리지 않지만, 앱의 나머지 파이프라인(채팅→API→TTS)이
 * 정상 동작하는지 먼저 확인할 수 있게 해줌.
 */
class NoOpLive2DController : Live2DController {
    override fun loadModel(modelDir: String, modelJsonFileName: String) {
        // TODO: Cubism SDK 연동 후 Live2DGLRenderer로 교체
    }

    override fun setMouthOpenY(value: Float) {
        // no-op
    }

    override fun startIdleMotion() {
        // no-op
    }

    override fun onSurfaceChanged(width: Int, height: Int) {
        // no-op
    }

    override fun release() {
        // no-op
    }
}
