Live2D 공식 사이트에서 다운로드한 Cubism Core `.aar` 파일을 이 폴더에 `CubismCore.aar`
이름으로 넣고, `app/build.gradle.kts`의 주석 처리된 의존성 줄을 활성화할 것.
자세한 내용은 `/docs/live2d_cubism_integration_guide.md` 참고.
