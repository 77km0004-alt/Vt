import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// local.properties에서 API 키 등 민감 정보 로드 (git에 커밋되지 않는 파일)
val localProperties = Properties().apply {
    val localPropertiesFile = rootProject.file("local.properties")
    if (localPropertiesFile.exists()) {
        load(FileInputStream(localPropertiesFile))
    }
}

android {
    namespace = "com.example.aivtuber"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.aivtuber"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        buildConfigField(
            "String",
            "GEMINI_API_KEY",
            "\"${localProperties.getProperty("GEMINI_API_KEY", "")}\""
        )
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Gemini REST 호출용 (공식 SDK 대신 순수 OkHttp 사용 - 의존성 최소화 및 버전 안정성 목적)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.json:json:20240303")

    // ────────────────────────────────────────────────────────────
    // ⚠️ Live2D Cubism SDK for Android — 라이선스 정책상 자동 포함 불가.
    // 아래 파일을 Live2D 공식 사이트(https://www.live2d.com/en/sdk/download/android/)에서
    // 직접 다운로드한 뒤 app/libs 폴더에 넣고 주석을 해제할 것:
    //
    // implementation(files("libs/CubismCore.aar"))
    // (Cubism SDK for Android Framework 소스는 아래 java 폴더 옆에
    //  live2d/framework 하위 경로로 직접 복사해 넣는 방식이 공식 가이드 방식임)
    // ────────────────────────────────────────────────────────────
}
