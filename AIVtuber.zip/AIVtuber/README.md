# AI VTuber (Android)

채팅 입력 → Gemini API 호출 → 답변 표시 + 안드로이드 내장 TTS 음성 출력 → 캐릭터가 말하는 것처럼 입모양이 움직이는 구조의 안드로이드 앱.

```
사용자 → [채팅 입력] → API 요청 → Gemini(AI 모델) → AI 답변
        → [답변 표시 + TTS 음성 출력] → 캐릭터가 말함
```

## 지금 포함된 것 / 아직 아닌 것

| 구성 요소 | 상태 |
|---|---|
| 채팅 UI (입력창 + 말풍선 리스트) | 완성 |
| Gemini API 연동 (REST, OkHttp) | 완성 |
| 안드로이드 내장 TTS | 완성 |
| 입모양 립싱크 | **근사치** — 실제 음량 기반이 아니라, TTS가 단어를 읽기 시작할 때마다 입을 열었다 닫는 방식 |
| 캐릭터 표시 | **플레이스홀더** — 입모양 2장(닫힘/열림)을 교체하는 방식. 실제 Live2D 모델 아님 |
| Live2D Cubism 모델 연동 | 미포함 (라이선스 정책상 SDK 자체를 넣을 수 없음) — `docs/live2d_cubism_integration_guide.md` 참고 |

## 실행 방법

1. Android Studio에서 이 폴더(AIVtuber)를 프로젝트로 열기.
2. `local.properties.example` 파일을 복사해서 `local.properties`로 이름을 바꾸고,
   `GEMINI_API_KEY=` 뒤에 [Google AI Studio](https://aistudio.google.com/)에서 발급받은
   Gemini API 키를 붙여넣기 (이 파일은 git에 커밋하지 말 것).
3. Gradle Sync 후 실행. 채팅창에 메시지를 입력하면 Gemini 답변이 오고, 동시에 TTS로 읽어주면서
   화면 위쪽 캐릭터의 입모양이 대략적으로 움직임.

## GitHub Actions로 APK 만들기

`.github/workflows/build-apk.yml`이 push할 때마다(또는 수동 실행 시) 디버그 APK를
빌드해서 Actions 아티팩트로 올려줌.

1. 이 프로젝트를 GitHub 저장소에 push.
2. 저장소 **Settings → Secrets and variables → Actions → New repository secret**에서
   이름 `GEMINI_API_KEY`, 값에는 실제 Gemini API 키를 등록 (코드에는 키가 절대 들어가지 않음).
3. `main` 브랜치에 push하거나, 저장소 **Actions** 탭 → `Build Debug APK` → **Run workflow**로 수동 실행.
4. 빌드가 끝나면 해당 워크플로우 실행 화면 하단 **Artifacts**에서
   `ai-vtuber-debug-apk`를 다운로드 (zip 안에 `app-debug.apk`가 들어있음).
5. 안드로이드 폰에 그 apk 파일을 옮기고, "출처를 알 수 없는 앱 설치" 허용 후 설치.

> ⚠️ 디버그 APK에는 Gemini API 키가 그대로 빌드에 박혀 들어감. apk를 디컴파일하면
> 키가 노출될 수 있으므로, 본인만 쓰는 용도가 아니라면 서버를 하나 두고 그쪽에서
> Gemini를 호출하는 구조로 바꾸는 게 안전함.

## 로컬에서 바로 실행해보기 (Android Studio)

1. Android Studio 최신 버전 설치 (Studio 안에 Android SDK가 같이 설치됨).
2. `AIVtuber` 폴더를 **Open** (Import 아님, 폴더 자체를 프로젝트로 열기).
3. 처음 열면 Gradle Sync가 자동으로 돔 — 인터넷 필요 (의존성 라이브러리 다운로드).
4. `local.properties.example`을 `local.properties`로 복사하고 `GEMINI_API_KEY` 채우기.
5. 상단 기기 선택에서 에뮬레이터(없으면 Device Manager에서 하나 생성) 또는
   USB로 연결한 실제 폰 선택 후 ▶(Run) 버튼.
6. 앱이 뜨면 입력창에 메시지 입력 → Gemini 답변이 오고 TTS로 읽어주면서 캐릭터 입이 움직임.

## 커스터마이징 포인트

- **캐릭터 성격/말투**: `data/GeminiRepository.kt`의 `systemInstruction` 값 수정.
- **TTS 언어**: `tts/TTSManager.kt`의 `tts?.language = Locale.KOREAN` 부분을 원하는 `Locale`로 교체.
- **Gemini 모델**: `data/GeminiRepository.kt`의 `model` 기본값(`"gemini-2.5-flash"`)을 원하는
  버전으로 교체 가능. 503(서버 과부하) 응답은 최대 2번 자동 재시도하도록 되어 있음.
- **진짜 Live2D 모델로 교체**: `docs/live2d_cubism_integration_guide.md` 참고. 핵심은
  `Live2DController` 인터페이스만 그대로 구현하면 나머지(채팅/TTS) 코드는 손댈 필요 없다는 것.

## 폴더 구조

```
AIVtuber/
├── app/src/main/java/com/example/aivtuber/
│   ├── MainActivity.kt          # 화면 조립 + 콜백 연결
│   ├── model/ChatMessage.kt     # 채팅 메시지 데이터 모델
│   ├── data/GeminiRepository.kt # Gemini REST 호출
│   ├── viewmodel/ChatViewModel.kt
│   ├── tts/TTSManager.kt        # 안드로이드 내장 TTS + 립싱크 콜백
│   ├── live2d/                  # 캐릭터 표시 (현재는 플레이스홀더 구현체)
│   └── ui/ChatAdapter.kt        # 채팅 RecyclerView 어댑터
├── app/src/main/res/            # 레이아웃, 색상, 아이콘, 플레이스홀더 캐릭터 이미지
├── docs/live2d_cubism_integration_guide.md
└── local.properties.example
```

## 알려진 제약

- TTS 립싱크는 실제 음량이 아니라 "단어 시작 시점"에 반응하는 근사치라서, 정교한 입모양
  동기화가 필요하면 별도 음성 합성(파일 생성 + RMS 분석) 방식으로 바꿔야 함.
- Live2D 모델은 Live2D 공식 SDK/모델 파일의 라이선스 문제로 이 저장소에 포함하지 않음 — 직접
  다운로드해서 연동 필요.
