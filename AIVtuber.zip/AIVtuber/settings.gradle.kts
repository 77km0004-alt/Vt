pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Live2D Cubism SDK의 CubismCore .aar 파일을 app/libs 에 넣어 참조하기 위한 로컬 저장소
        flatDir {
            dirs("app/libs")
        }
    }
}

rootProject.name = "AIVtuber"
include(":app")
