# Live2D Cubism SDK 실제 연동 가이드

현재 앱은 `Live2DPlaceholderController`(입모양 이미지 2장 교체)로 캐릭터를 표시함.
실제 Live2D 모델(움짤 아바타)을 쓰려면 아래 단계를 거쳐야 함. Live2D의 Cubism SDK는
**라이선스 정책상 이 프로젝트에 직접 포함할 수 없고**, 반드시 공식 사이트에서 본인이
직접 다운로드해야 함.

## 1. 필요한 것 준비

1. **Cubism Editor**로 만든 캐릭터 모델 (`.model3.json` 및 관련 리소스 일체), 또는
   Live2D가 배포하는 무료 샘플 모델(Hiyori, Mao 등)을 공식 사이트에서 다운로드.
2. **Cubism SDK for Android** — https://www.live2d.com/en/sdk/download/android/ 에서
   로그인 후 다운로드 (Cubism Core 네이티브 라이브러리 + Java Framework 소스 포함).

## 2. 프로젝트에 배치

- 다운로드한 `Core` 폴더의 `.aar`(또는 `.so` + 헤더)를 `app/libs/CubismCore.aar` 로 복사하고,
  `app/build.gradle.kts`에서 주석 처리된 `implementation(files("libs/CubismCore.aar"))` 줄의
  주석을 해제.
- Framework 소스(Java/Kotlin)는 공식 SDK가 안내하는 방식대로
  `app/src/main/java/com/example/aivtuber/live2d/framework/` 하위에 복사.
- 모델 리소스(`.model3.json`, `.moc3`, 텍스처 등)는
  `app/src/main/assets/live2d/<모델명>/` 아래에 통째로 복사.

## 3. Live2DController 구현체 교체

`MainActivity.setupCharacter()`에서 `Live2DPlaceholderController` 대신
아래와 같은 형태의 실제 구현체를 사용하도록 한 줄만 바꾸면 됨
(ChatViewModel이나 TTSManager 쪽 코드는 전혀 손댈 필요 없음 — 인터페이스로 분리해둔 이유).

새 구현체는 대략 다음과 같은 형태가 됨 (아래는 실제 컴파일되는 코드가 아니라
Cubism 공식 매뉴얼에 나오는 API를 어떻게 우리 인터페이스에 연결하면 되는지 보여주는
참고용 예시임 — SDK를 넣은 뒤 본인 환경에 맞게 작성해야 함):

```kotlin
class Live2DCubismController(
    private val glSurfaceView: GLSurfaceView,
    private val assetContext: Context
) : Live2DController {

    private var mouthParameterId: CubismId? = null
    private var model: CubismModel? = null

    override fun loadModel(modelDir: String, modelJsonFileName: String) {
        // 1) assets/live2d/<modelDir>/<modelJsonFileName> 로드
        // 2) CubismModelSettingJson으로 파싱 → moc3/텍스처/모션 로드 → CubismModel 생성
        // 3) 립싱크에 쓸 파라미터 ID 확보
        //    mouthParameterId = CubismFramework.getIdManager().getId("ParamMouthOpenY")
    }

    override fun setMouthOpenY(value: Float) {
        // model?.setParameterValue(mouthParameterId, value)
        // (Cubism 매뉴얼 기준: 0=다뭄, 1=활짝 벌림)
    }

    override fun startIdleMotion() {
        // 로드된 idle 모션 그룹을 모션 매니저에 재생 요청
    }

    override fun onSurfaceChanged(width: Int, height: Int) {
        // 투영 행렬 갱신
    }

    override fun release() {
        // CubismFramework 관련 리소스 dispose
    }
}
```

핵심 매핑은 **`TTSManager`가 만들어내는 0~1 사이의 `mouthOpenValue` 값을
Cubism의 `ParamMouthOpenY` 파라미터에 그대로 넣어주는 것**뿐임. 나머지(모델 로딩,
OpenGL 렌더링 루프)는 Cubism 공식 SDK 샘플 프로젝트 구조를 그대로 따르면 됨.

## 4. 참고 링크

- Cubism SDK 다운로드: https://www.live2d.com/en/sdk/download/android/
- 공식 매뉴얼(립싱크 관련): https://docs.live2d.com/en/cubism-sdk-manual/lipsync/
- 공식 매뉴얼(Java Framework 사용법): https://docs.live2d.com/en/cubism-sdk-manual/use-framework-java/
